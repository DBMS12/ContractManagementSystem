package model;

public class Right {

}
