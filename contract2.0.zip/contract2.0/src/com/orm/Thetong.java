package com.orm;

public class Thetong
{
	private int id;
	private String mingcheng;
	private String jiafangfuzeren;
	private String yifangfuzeren;
	
	private String kaishishijian;
	private String jieshushijian;
	private int jine;
	private String beizhu;
	
	private String zt;//����--ɾ��
	
	public int getId()
	{
		return id;
	}
	public void setId(int id)
	{
		this.id = id;
	}
	public String getMingcheng()
	{
		return mingcheng;
	}
	public void setMingcheng(String mingcheng)
	{
		this.mingcheng = mingcheng;
	}
	public String getJiafangfuzeren()
	{
		return jiafangfuzeren;
	}
	public void setJiafangfuzeren(String jiafangfuzeren)
	{
		this.jiafangfuzeren = jiafangfuzeren;
	}
	public String getYifangfuzeren()
	{
		return yifangfuzeren;
	}
	
	public String getZt()
	{
		return zt;
	}
	public void setZt(String zt)
	{
		this.zt = zt;
	}
	public void setYifangfuzeren(String yifangfuzeren)
	{
		this.yifangfuzeren = yifangfuzeren;
	}
	public String getKaishishijian()
	{
		return kaishishijian;
	}
	public void setKaishishijian(String kaishishijian)
	{
		this.kaishishijian = kaishishijian;
	}
	public String getJieshushijian()
	{
		return jieshushijian;
	}
	public void setJieshushijian(String jieshushijian)
	{
		this.jieshushijian = jieshushijian;
	}
	public int getJine()
	{
		return jine;
	}
	public void setJine(int jine)
	{
		this.jine = jine;
	}
	public String getBeizhu()
	{
		return beizhu;
	}
	public void setBeizhu(String beizhu)
	{
		this.beizhu = beizhu;
	}
	
}
